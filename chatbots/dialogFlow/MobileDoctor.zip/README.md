# MobileDoctor_DialogFlow_backup
Dialog flow version 2 chat bot which and predict Chronicle kidney disease using external webhook. That ML mode is deployed in heroku server as a flask project. 

# Integrated to with facebook

![](https://firebasestorage.googleapis.com/v0/b/health-care-support-syst-edba2.appspot.com/o/Dialog%20Flow%20data%2FFacebook%20integration.JPG?alt=media&token=005bb9df-e1cf-46a1-a9b4-92ba2ce84b43)

# Integrated with Telegram
<img src='https://firebasestorage.googleapis.com/v0/b/health-care-support-syst-edba2.appspot.com/o/Dialog%20Flow%20data%2FTelegram%20integration.png?alt=media&token=a0cfad61-b0c0-49ad-84e7-d90833908da2' width=255 height=500>

# Integration with flutter app
<img src='https://firebasestorage.googleapis.com/v0/b/health-care-support-syst-edba2.appspot.com/o/Dialog%20Flow%20data%2FFlutter%20ap%20Integration.png?alt=media&token=d258545d-d3a2-4df8-869f-40235e04fd1a' width=255 height=500>
